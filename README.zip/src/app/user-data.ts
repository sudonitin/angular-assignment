import { Users } from './user';

export const USERS : Users[] = [
    {
    email : 'asd@gmail.com',
    occupation : 'housekeeper',
    username : 'asdfg',
    password : '123456' 
    },
    {
    email : 'qwerty@gmail.com',
    occupation : 'service',
    username : 'goodboy',
    password : '123456' 
    },
    {
        email : 'demo@gmail.com',
        occupation : 'business',
        username : 'demoguy',
        password : '123456' 
        }
];