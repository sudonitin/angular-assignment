export class Users{
    email : string;
    occupation : string;
    username : string;
    password : string; 
}